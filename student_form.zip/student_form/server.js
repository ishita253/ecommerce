require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");

const app = express();

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

const mongoUrl = process.env.MONGO_URI || "mongodb://localhost:27017";
const client = new MongoClient(mongoUrl);

let db;
client.connect()
  .then(() => {
    db = client.db("studentsDB");
    console.log("Connected to MongoDB");
  })
  .catch((err) => console.error("MongoDB Connection Error:", err));

// Add a new student
app.post("/students", async (req, res) => {
  try {
    const { name, email, age, branch, division, rollNo, contact } = req.body;
    const collection = db.collection("students");
    await collection.insertOne({ name, email, age, branch, division, rollNo, contact });
    res.status(201).json({ message: "Student added successfully!" });
  } catch (error) {
    res.status(500).json({ message: "Error saving student", error });
  }
});

// Get all students
app.get("/students", async (req, res) => {
  try {
    const collection = db.collection("students");
    const students = await collection.find().toArray();
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: "Error fetching students", error });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
