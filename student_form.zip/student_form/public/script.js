document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("studentForm");
    const studentList = document.getElementById("studentList");

    // Fetch students
    const fetchStudents = async () => {
        studentList.innerHTML = "";
        try {
            const res = await fetch("/students");
            const students = await res.json();
            students.forEach(student => {
                const li = document.createElement("li");
                li.textContent = `${student.name} | ${student.email} | ${student.age} | ${student.branch} | ${student.division} | Roll No: ${student.rollNo} | Contact: ${student.contact}`;
                studentList.appendChild(li);
            });
        } catch (error) {
            console.error("Error fetching students:", error);
        }
    };

    // Handle form submission
    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const age = document.getElementById("age").value;
        const branch = document.getElementById("branch").value;
        const division = document.getElementById("division").value;
        const rollNo = document.getElementById("rollNo").value;
        const contact = document.getElementById("contact").value;

        try {
            const res = await fetch("/students", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name, email, age, branch, division, rollNo, contact }),
            });

            if (res.ok) {
                alert("Student added successfully!");
                form.reset();
                fetchStudents();
            } else {
                alert("Error adding student.");
            }
        } catch (error) {
            console.error("Error adding student:", error);
        }
    });

    fetchStudents();
});
